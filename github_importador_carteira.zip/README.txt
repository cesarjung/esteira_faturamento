📦 COMO USAR NO GITHUB ACTIONS

1. Crie um repositório novo no GitHub (ex: importador-carteira)

2. Faça upload destes arquivos:
   - importador_carteira.py
   - requirements.txt
   - .github/workflows/agendador.yml

3. Vá em:
   Settings > Secrets and variables > Actions > New secret

   Nome: GOOGLE_CREDENTIALS_JSON
   Valor: cole o conteúdo do seu credenciais.json (minificado em uma linha)

4. O GitHub irá rodar automaticamente todo dia às 06:00 da manhã (horário de Brasília)

5. Você pode também executar manualmente indo em:
   "Actions" > "Importador Carteira" > "Run workflow"

✅ Pronto! Seu script rodará 100% em nuvem, gratuitamente, com logs e histórico.
