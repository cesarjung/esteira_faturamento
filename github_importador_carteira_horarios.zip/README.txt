📦 COMO USAR COM GITHUB ACTIONS (4 horários por dia)

1. Crie um repositório no GitHub (ex: importador-carteira)
2. Faça upload de todos os arquivos deste pacote, incluindo a pasta .github
3. Vá em Settings > Secrets and variables > Actions > New secret
   - Nome: GOOGLE_CREDENTIALS_JSON
   - Valor: conteúdo do seu credenciais.json (em uma única linha JSON)

🕒 O script será executado automaticamente todos os dias às:
- 10:00
- 12:00
- 15:00
- 19:00 (horário de Brasília)

Você também pode rodar manualmente em: "Actions" > "Run workflow"
